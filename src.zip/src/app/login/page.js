"use client";

import { signIn, signOut, useSession } from "next-auth/react";
import Image from "next/image";
import React, { useState } from "react";

const page = () => {
  const session = useSession();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(email, password);
  };

  console.log("session", session);

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      {session?.status !== "unauthenticated" ? (
        <div>
          Signed in as {session?.user?.email} <br />
          <button onClick={() => signOut()}>Sign out</button>
        </div>
      ) : (
        <form
          style={{
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
            gap: "20px",
            alignItems: "center",
          }}
          onSubmit={handleSubmit}
        >
          <h2>Login Page</h2>
          <input
            name="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            name="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button type="submit">Submit</button>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <Image src="/google.svg" alt="google" height="40" width="40" />
            <Image
              onClick={() => signIn()}
              src="/github.png"
              alt="github"
              height="40"
              width="40"
            />
            <Image
              src="/microsoft.svg"
              alt="microsoft"
              height="40"
              width="40"
            />
            <Image src="/facebook.svg" alt="facebook" height="40" width="40" />
          </div>
        </form>
      )}
    </div>
  );
};

export default page;
